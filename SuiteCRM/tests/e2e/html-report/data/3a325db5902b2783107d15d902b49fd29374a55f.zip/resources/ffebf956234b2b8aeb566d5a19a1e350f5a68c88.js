
            // Web Worker for heavy pipeline calculations
            self.onmessage = function(e) {
                const { type, data, taskId } = e.data;
                let result;
                
                switch (type) {
                    case 'calculateTimeInStage':
                        result = calculateTimeInStage(data);
                        break;
                    case 'sortDeals':
                        result = sortDeals(data);
                        break;
                    case 'filterDeals':
                        result = filterDeals(data);
                        break;
                    case 'aggregateMetrics':
                        result = aggregateMetrics(data);
                        break;
                    default:
                        result = { error: 'Unknown task type' };
                }
                
                self.postMessage({ taskId, result });
            };
            
            function calculateTimeInStage(deals) {
                return deals.map(deal => {
                    const stageDate = new Date(deal.stage_entered_date_c || deal.date_modified);
                    const now = new Date();
                    const daysDiff = Math.floor((now - stageDate) / (1000 * 60 * 60 * 24));
                    
                    return {
                        ...deal,
                        days_in_stage: daysDiff,
                        stage_color_class: daysDiff > 30 ? 'stage-red' : 
                                         daysDiff > 14 ? 'stage-orange' : 'stage-normal'
                    };
                });
            }
            
            function sortDeals(data) {
                const { deals, sortBy, sortOrder } = data;
                
                return deals.sort((a, b) => {
                    let aVal = a[sortBy];
                    let bVal = b[sortBy];
                    
                    // Handle focus ordering
                    if (sortBy === 'focus_order') {
                        aVal = a.focus_flag_c ? (a.focus_order_c || 0) : 999999;
                        bVal = b.focus_flag_c ? (b.focus_order_c || 0) : 999999;
                    }
                    
                    if (typeof aVal === 'string') {
                        aVal = aVal.toLowerCase();
                        bVal = bVal.toLowerCase();
                    }
                    
                    if (sortOrder === 'desc') {
                        return aVal < bVal ? 1 : aVal > bVal ? -1 : 0;
                    } else {
                        return aVal > bVal ? 1 : aVal < bVal ? -1 : 0;
                    }
                });
            }
            
            function filterDeals(data) {
                const { deals, filters } = data;
                
                return deals.filter(deal => {
                    for (const [field, value] of Object.entries(filters)) {
                        if (field === 'focus_only' && value && !deal.focus_flag_c) {
                            return false;
                        }
                        if (field === 'stage' && value && deal.pipeline_stage_c !== value) {
                            return false;
                        }
                        if (field === 'assigned_user' && value && deal.assigned_user_id !== value) {
                            return false;
                        }
                        if (field === 'amount_min' && value && (deal.amount || 0) < value) {
                            return false;
                        }
                        if (field === 'amount_max' && value && (deal.amount || 0) > value) {
                            return false;
                        }
                    }
                    return true;
                });
            }
            
            function aggregateMetrics(deals) {
                const metrics = {
                    total_deals: deals.length,
                    total_value: 0,
                    avg_value: 0,
                    stages: {},
                    users: {}
                };
                
                deals.forEach(deal => {
                    const amount = parseFloat(deal.amount) || 0;
                    metrics.total_value += amount;
                    
                    // Stage metrics
                    const stage = deal.pipeline_stage_c || 'unknown';
                    if (!metrics.stages[stage]) {
                        metrics.stages[stage] = { count: 0, value: 0 };
                    }
                    metrics.stages[stage].count++;
                    metrics.stages[stage].value += amount;
                    
                    // User metrics
                    const user = deal.assigned_user_id || 'unassigned';
                    if (!metrics.users[user]) {
                        metrics.users[user] = { count: 0, value: 0 };
                    }
                    metrics.users[user].count++;
                    metrics.users[user].value += amount;
                });
                
                metrics.avg_value = metrics.total_deals > 0 ? 
                    metrics.total_value / metrics.total_deals : 0;
                
                return metrics;
            }
        